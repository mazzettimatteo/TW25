"use strict";

const key = "f1e2b72a"; 
let title = "Knives Out";

title = title.replace(" ","+"); 

async function go() {
  let url = "https://www.omdbapi.com/?t=" + title + "&apikey=" + key;

  let result = document.getElementById("result");
  let img = document.getElementById("image");

  try {
    let response = await fetch(url);
	let output = await response.json();

	let body = "";

	body += "<tr><td> Titolo </td><td>";

	body = body + output.Title + "</td></tr>";
	
	body = body + "<tr><td> Anno </td><td>";

	body = body + output.Year + "</td></tr>";
	
	body = body + "<tr><td> Attori </td><td>";

	body = body + output.Actors + "</td></tr>";
	
	body = body + "<tr><td> Riassunto </td><td>";

	body = body + output.Plot + "</td></tr>";
	
	result.innerHTML = body;

	img.innerHTML = "<img style='height:20%;' src='"+output.Poster+"'/>"  
		
  } catch(e) {
    result.innerHTML = "Cannot download from URL";
  }
	
}