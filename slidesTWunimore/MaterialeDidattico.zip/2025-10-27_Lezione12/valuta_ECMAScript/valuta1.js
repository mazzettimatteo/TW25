"use strict";

let key = "4ebc45b13cb1d90fdffb81ef";

function verificaScelta(id) {
	let v = document.getElementById(id).value;
	
	if (v == "") {
		document.getElementById(id).className = "error";
	}
	else
		document.getElementById(id).className = "ok";
}

function verificaNumero() {
	let numero = document.getElementById("n1").value;
	
	if (isNaN(numero)) {
		alert("inserisci un numero!");
		document.getElementById("n1").className = "error";
	}
	else 
		document.getElementById("n1").className = "ok";
		
}

async function calcolaCambio() {
	let v1 = document.getElementById("valuta1").value;
	let v2 = document.getElementById("valuta2").value;
	let numero = document.getElementById("n1").value;
	
	let n2 = document.getElementById("n2");
	let par = document.getElementById("par");
	
	let risultato;
	
	if (v1 == "" || v2 == "") {
		par.innerHTML = "Errore: seleziona entrambe le valute";
		return;
	}
	
	let url = "https://v6.exchangerate-api.com/v6/" 
	url += key + "/pair/"+v1+"/"+v2;
	
	try {
		let response = await fetch(url);
		let output = await response.json();
		let body = "";
		
		let cambio =  output.conversion_rate;
		
		risultato = numero * cambio;
		risultato = Math.floor(100*risultato)/100;
		
		n2.value = risultato;
		n2.className = "ok";
	
		let S = numero + " " + v1 + " corrispondono a ";
 		S += risultato + " " + v2;
	
		par.innerHTML = S;
	} catch(e) {
		result.innerHTML = "Cannot download from URL";
	}
	
}

