var EUR2GBP = 0.92;
var EUR2CHF = 1.08;
var GBP2CHF = 1.18;
var GBP2EUR = Math.floor(100/EUR2GBP)/100;
var CHF2EUR = Math.floor(100/EUR2CHF)/100;
var CHF2GBP = Math.floor(100/GBP2CHF)/100;

function verificaScelta(id) {
	var v = document.getElementById(id).value;
	
	if (v == "") {
		document.getElementById(id).className = "error";
	}
	else
		document.getElementById(id).className = "ok";
}

function verificaNumero() {
	var n1 = document.getElementById("n1");
	var numero = n1.value;
	
	if (isNaN(numero)) {
		alert("inserisci un numero!");
		n1.className = "error";
	}
	else 
		n1.className = "ok";
		
}

function calcolaCambio() {
	var v1 = document.getElementById("valuta1").value;
	var v2 = document.getElementById("valuta2").value;
	var numero = document.getElementById("n1").value;
	var risultato;
	
	if (v1 == "" || v2 == "") {
		var S = "Errore: seleziona entrambe le valute";
		document.getElementById("par").innerHTML = S;
		return;
	}
	
	var scambio;
	if (v1 == v2)
		scambio = 1;
	else
		scambio = v1 + "2" + v2;
	
	/*
	if (v1 == v2)
		risultato = numero;
	else if (v1 == "EUR" && v2 == "GBP")
		risultato = numero * EUR2GBP;
	else if (v1 == "EUR" && v2 == "CHF")
		risultato = numero * EUR2CHF;
	else if (v1 == "GBP" && v2 == "EUR")
		risultato = numero * GBP2EUR;
	else if (v1 == "GBP" && v2 == "CHF")
		risultato = numero * GBP2CHF;
	else if (v1 == "CHF" && v2 == "EUR")
		risultato = numero * CHF2EUR;
	else if (v1 == "CHF" && v2 == "GBP")
		risultato = numero * CHF2GBP;
	else
		alert("Errore!")
	*/
	
	risultato = numero * eval(scambio);
	risultato = Math.floor(100*risultato)/100;
	
	
	document.getElementById("n2").value = risultato
	
	var S = numero + " " + v1 + " corrispondono a " + risultato + " " + v2;
	
	document.getElementById("par").innerHTML = S;
	
}








