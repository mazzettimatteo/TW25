import './App.css'

import CitySelector from './CitySelector'
import DateSelector from './DateSelector'

import {useState} from 'react'

export default function App() {
  const [city, setCity] = useState('');
  const [date, setDate] = useState('');

  return (
    <div>
      <CitySelector city={city} setCity={setCity} />
      <p>Il valore della citt&agrave; &egrave;: {city}</p>
      <DateSelector date={date} setDate={setDate}/>
      <p>Il valore della data &egrave;: {date}</p>
    </div>
  )
}
