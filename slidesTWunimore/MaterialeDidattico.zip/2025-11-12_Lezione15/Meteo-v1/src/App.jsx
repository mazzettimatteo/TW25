import './App.css'

import CitySelector from './CitySelector'

import {useState} from 'react'

export default function App() {
  const [city, setCity] = useState('');
  
  return (
    <div>
      <CitySelector city={city} setCity={setCity} />
      <p>Il valore della citt&agrave; &egrave;: {city}</p>
    </div>
  )
}
