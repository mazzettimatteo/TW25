import TextField from '@mui/material/TextField';
  
export default function CitySelector({city, setCity}) {
  function handleChange(event) {
    setCity(event.target.value);
  }
  
  return (
    <TextField label="Citt&agrave;" variant="outlined" value={city} onChange={handleChange} error={city==""}/>
  );
}