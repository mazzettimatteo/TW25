import './App.css'

import CitySelector from './CitySelector'
import DateSelector from './DateSelector'
import Forecast from './Forecast'

import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';

import {useState} from 'react'

export default function App() {
  const [city, setCity] = useState('');
  const [date, setDate] = useState('');

  return (
    <Stack direction="column" spacing={3} padding={3}>
      <CitySelector city={city} setCity={setCity} />
      <DateSelector date={date} setDate={setDate}/>
      {city != '' && date != '' ? <Forecast city={city} date={date} /> : <Typography>Seleziona una citt&agrave; e una data</Typography>}
    </Stack>
  )
}
