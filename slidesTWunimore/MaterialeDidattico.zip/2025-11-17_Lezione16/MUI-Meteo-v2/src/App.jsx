import "./App.css";

import CitySelector from "./CitySelector";
import DateSelector from "./DateSelector";
import Forecast from "./Forecast";

import Stack from "@mui/material/Stack";
import AppBar from "@mui/material/AppBar";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import Toolbar from "@mui/material/Toolbar";

import { ThemeProvider, createTheme } from "@mui/material/styles";
import CssBaseline from "@mui/material/CssBaseline";

import Brightness7Icon from "@mui/icons-material/Brightness7";
import Brightness4Icon from "@mui/icons-material/Brightness4";

import { useState } from "react";

import useMediaQuery from "@mui/material/useMediaQuery";

export default function App() {
  const [city, setCity] = useState("");
  const [date, setDate] = useState("");

  const isLandscape = useMediaQuery("(orientation: landscape)");

  const isDark = useMediaQuery("(prefers-color-scheme: dark)");

  const [theme, setTheme] = useState(
    createTheme({
      palette: {
        mode: isDark ? "dark" : "light",
      },
    }),
  );

  function toggleTheme() {
    let t;
    if (theme.palette.mode == "dark")
      t = createTheme({ palette: { mode: "light" } });
    else t = createTheme({ palette: { mode: "dark" } });
    setTheme(t);
  }

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6" sx={{ flexGrow: 1 }}>
            Meteo
          </Typography>
          <IconButton onClick={toggleTheme} color="inherit">
            {theme.palette.mode === "dark" ? (
              <Brightness7Icon />
            ) : (
              <Brightness4Icon />
            )}
          </IconButton>
        </Toolbar>
      </AppBar>
      <Stack
        direction={isLandscape ? "row" : "column"}
        spacing={3}
        sx={{ width: "100%", height: "100%" }}
      >
        <Stack
          direction="column"
          spacing={3}
          padding={3}
          sx={isLandscape ? { width: "50%" } : { width: "100%" }}
        >
          <CitySelector city={city} setCity={setCity} />
          <DateSelector date={date} setDate={setDate} />
        </Stack>
        {city != "" && date != "" ? (
          <Forecast
            city={city}
            date={date}
            sx={isLandscape ? { width: "50%" } : { width: "100%" }}
          />
        ) : (
          <Typography>Seleziona una citt&agrave; e una data</Typography>
        )}
      </Stack>
    </ThemeProvider>
  );
}
