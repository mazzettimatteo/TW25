#import RPi.GPIO as GPIO # per Raspberry o emulatore online
from EmulatorGUI import GPIO # per emulatore scaricato (usa EmulatorGUI, PIN, TypeChecker)
import time

def io(on):
        if on == True:
                GPIO.output(15, GPIO.HIGH)
        else:
                GPIO.output(15, GPIO.LOW)

        if GPIO.input(23) == 1:
                print("Button currently pressed")

def loop():
        try:
                GPIO.setmode(GPIO.BCM)
                GPIO.setup(15,GPIO.OUT)
                GPIO.setup(23,GPIO.IN)
                GPIO.setwarnings(False)
                while True:
                        io(True)
                        time.sleep(1)
                        io(False)
                        time.sleep(1)
        finally:
                GPIO.cleanup()

if __name__ == '__main__':
        loop()
