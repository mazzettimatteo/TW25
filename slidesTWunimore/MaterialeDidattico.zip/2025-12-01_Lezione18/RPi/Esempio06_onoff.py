#import RPi.GPIO as GPIO # per Raspberry o emulatore online
from EmulatorGUI import GPIO # per emulatore scaricato (usa EmulatorGUI, PIN, TypeChecker)
import time

def loop():
        try:
                GPIO.setmode(GPIO.BCM)
                GPIO.setup(24,GPIO.OUT)
                GPIO.setup(23,GPIO.IN)
                GPIO.setup(22,GPIO.IN)
                GPIO.setwarnings(False)
                GPIO.output(24, GPIO.LOW)
                while True:
                        if GPIO.input(23) == 1:
                                GPIO.output(24, GPIO.HIGH)
                                time.sleep(1)
                        if GPIO.input(22) == 1:
                                GPIO.output(24, GPIO.LOW)
                                time.sleep(1)
        finally:
                GPIO.cleanup()

if __name__ == '__main__':
        loop()
