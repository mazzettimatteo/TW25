#import RPi.GPIO as GPIO # per Raspberry o emulatore online
from EmulatorGUI import GPIO # per emulatore scaricato (usa EmulatorGUI, PIN, TypeChecker)

GPIO.setmode(GPIO.BCM)

GPIO.setup(24,GPIO.OUT)

GPIO.output(24,1)

GPIO.setup(23,GPIO.IN)

print(GPIO.input(23)) # stampa 0 perché non c'è corrente

GPIO.cleanup()
