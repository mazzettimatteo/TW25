#import RPi.GPIO as GPIO # per Raspberry o emulatore online
from EmulatorGUI import GPIO # per emulatore scaricato (usa EmulatorGUI, PIN, TypeChecker)
import time

def loop():
        try:
                GPIO.setmode(GPIO.BCM)
                GPIO.setup(15,GPIO.OUT)
                GPIO.setwarnings(False)
                for i in range(10):
                        GPIO.output(15,GPIO.HIGH)
                        time.sleep(1)
                        GPIO.output(15,GPIO.LOW)
                        time.sleep(1)
        finally:
                GPIO.cleanup()

if __name__ == '__main__':
        loop()

