from machine import Pin
from time import sleep

red = Pin(4,Pin.OUT)
green = Pin(5,Pin.OUT)

def loop():
  global red, green
  
  while True:
    red.value(True)
    green.value(False)
    sleep(1)
    red.value(0)
    green.value(1)
    sleep(1)

loop()



