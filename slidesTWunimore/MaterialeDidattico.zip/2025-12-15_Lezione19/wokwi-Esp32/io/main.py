from machine import Pin
from time import sleep

red = Pin(4,Pin.OUT)
green = Pin(5,Pin.OUT)
button = Pin(14,Pin.IN)

def io(on):
  global red, green, button
  
  if on == True:
    red.value(1)
    green.value(0)
  else:
    red.value(0)
    green.value(1)
  
  if button.value() == 1:
    print("Button currently pressed")

def loop():
  while True:
    io(True)
    sleep(1)
    io(False)
    sleep(1)

loop()