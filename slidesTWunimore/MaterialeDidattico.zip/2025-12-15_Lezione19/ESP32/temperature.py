from machine import Pin
from time import sleep
import onewire, ds18x20

red = Pin(4,Pin.OUT)
green = Pin(5,Pin.OUT)

temp = Pin(15,Pin.IN)
onewire = onewire.OneWire(temp)
sensor = ds18x20.DS18X20(onewire)

sensor_id = bytearray(b'(w\x12\xea\r\x00\x00\xbe')

def read_temp():
  global sensor, sensor_id
  
  sensor.convert_temp()
  sleep(1)
  temp = sensor.read_temp(sensor_id)
  print("Temperature is", temp)

def io(on):
  global red, green
  
  if on == True:
    red.value(1)
    green.value(0)
  else:
    red.value(0)
    green.value(1)
  
  read_temp()

def loop():  
  while True:
    io(True)
    io(False)

loop()


