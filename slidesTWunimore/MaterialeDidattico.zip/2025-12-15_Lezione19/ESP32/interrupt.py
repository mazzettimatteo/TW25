from machine import Pin
from time import sleep

red = Pin(4,Pin.OUT)
green = Pin(5,Pin.OUT)
button = Pin(14,Pin.IN,Pin.PULL_DOWN)

def pressed(pin):
  if button.value() == 1:
    print("Button pressed detected on pin", pin)

def loop():
  global red, green, button
  
  button.irq(pressed,Pin.IRQ_RISING)
  
  while True:
    red.value(1)
    green.value(0)
    sleep(1)
    red.value(0)
    green.value(1)
    sleep(1)

loop()


