"use strict";

const key = "f1e2b72a"; /*a5ed7258 nuova*/

async function go() {
  let testo = document.getElementById("testo").value;
  
  let url = "https://www.omdbapi.com/?s=" + testo + "&apikey=" + key;

  let result = document.getElementById("result");
  
  try {
    let response = await fetch(url);
	let output = await response.json();
	
	let v = output.Search;
	let body = "";
	
	for (let i = 0; i< v.length; i++) {
		//versione 1
		//body += "<li>" + v[i].Title + " ("+ v[i].Year + ")" + "</li>";
		
		// versione 2
		
		body += "<li><a href=\'";
		body += v[i].Poster + "\' target='_blank'>";
		body += v[i].Title + " ("+ v[i].Year + ")"
		body += "</a></li>";
		
	}
	
	result.innerHTML = body;
		
  } catch(e) {
    result.innerHTML = "Cannot download from URL";
  }
	
}

/*https://www.omdbapi.com/?s=nomadland&apikey=a5ed7258&y=2020*/