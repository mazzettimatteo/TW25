"use strict";
/* nuova chiave: 21fd57ae543deb353d9fabff0d3299e3*/

const token = "24c84cde26320ec0c8c1dbedbdce66b4";
//  NOTA:   gli studenti sono invitati a generare la propria chiave dal sito
// https://openweathermap.org, seguendo le iscruzioni sulle slide 
// e a sostituirne il valore nella variabile token

const url = "http://api.openweathermap.org/data/2.5/forecast?q=Reggio+Emilia,Italy&appid="+token;

let day;
let month;
let year;
let hour;
let min;

function evaluateDayHour(dayHour) {
  let x = dayHour.split(" ");
  let d = x[0];
  let h = x[1];
	
  let y = d.split("-");
  let z = h.split(":");
  day = y[2];
  month = y[1];
  year = y[0];
	
  hour = z[0];
  min = z[1];
}

function initialize() {
  let S = "";
  const today = new Date();
  let g = today.getDate();
  if (g < 10)
	g = '0' + g;
  let m = today.getMonth()+1;
  let a = today.getFullYear();
	
  S = S + "<option id='---'> --- </option>";
  S = S + "<option id='g0'>" + g + "/" + m + "/" + a + "</option>";

  const millis = 1000*60*60*24;
  for (let i=1; i<=4; i++) {
	let newDate = new Date(today.getTime() + i * millis);
		
	g = newDate.getDate();
	if (g < 10)
  	  g = '0' + g;
	m = newDate.getMonth()+1;
	a = newDate.getFullYear();		
	S = S + "<option id=g" + i + ">" + g + "/" + m + "/" + a + "</option>";	
  }		

  document.getElementById("day").innerHTML = S;
}

function findImage(T) {
  if (T == "Rain")	
 	return "pioggia";
  if (T == "Clear")	
	return "sole";
  if (T == "Clouds")	
	return "nuvola";
  if (T == "Snow")
	return "neve";
}

async function go() {
  const dateForecast = document.getElementById("day").value; // data scelta nella tendina
	
  const result = document.getElementById("result");
   
  try {
   
	const response = await fetch(url);
	const output = await response.json();

	let body = "";
	
	let i = 0;
	let dayHour = output.list[i].dt_txt;	
	evaluateDayHour(dayHour); // data e ora del primo elemento della lista
	
	let dateList = day + "/" + month + "/" + year; // data del primo elemento della lista
	
	while (dateList != dateForecast) {
	  // se la data nella tendina è diversa da quella attuale, incremento fino a quando trovo per la prima volta la data nella tendina
	  i++; 
	  dayHour = output.list[i].dt_txt;
	  evaluateDayHour(dayHour);
	  dateList = day + "/" + month + "/" + year; 
	}

	while (dateList == dateForecast) {
	  body += "<tr><td>";

      dayHour = output.list[i].dt_txt;
	
	  evaluateDayHour(dayHour);
	
	  body = body + day + "/" + month + "/" + year + "</td><td>";
	
	  body = body + hour + ":" + min + "</td><td>";
	
	  body += output.list[i].weather[0].main;
		
	  body += "</td><td>";
		
	  let strImage = findImage(output.list[i].weather[0].main);

	  body += "<img src = \'img/" + strImage + ".png\' />";

	  body += "</td><td>";

	  body += Math.floor(output.list[i].main.temp - 273.15);

	  body += "</td> </tr>";
		
	  i++; 
	  dayHour = output.list[i].dt_txt;
	  evaluateDayHour(dayHour);
	  dateList = day + "/" + month + "/" + year; 
	}
	
	result.innerHTML = body; 
  } catch(e) {
    result.innerHTML = "Cannot download from URL";
  }
}

