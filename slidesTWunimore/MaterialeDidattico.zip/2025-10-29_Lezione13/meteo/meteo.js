"use strict";
/* nuova chiave: 21fd57ae543deb353d9fabff0d3299e3*/

const token = "24c84cde26320ec0c8c1dbedbdce66b4";
//  NOTA:   gli studenti sono invitati a generare la propria chiave dal sito
// https://openweathermap.org, seguendo le iscruzioni sulle slide 
// e a sostituirne il valore nella variabile token

const url = "http://api.openweathermap.org/data/2.5/forecast?q=Reggio+Emilia,Italy&appid="+token;

let day;
let month;
let year;
let hour;
let min;

function evaluatedayHour(dayHour) {
  day = dayHour[8].concat(dayHour[9]);
  month = dayHour[5].concat(dayHour[6]);
  year = dayHour[0].concat(dayHour[1]);
  year = year.concat(dayHour[2]);
  year = year.concat(dayHour[3]);
	
  hour = dayHour[11].concat(dayHour[12]);
  min = dayHour[14].concat(dayHour[15]);
}

async function go() {	
  const result = document.getElementById("result");

  try {
    const response = await fetch(url);
	const output = await response.json();

	let body = "";
	let dayHour;
	
	for(let i = 0; i < 8; i++) {
	  body = body + "<tr><td>";

      dayHour = output.list[i].dt_txt;
		
	  evaluatedayHour(dayHour);
	
	  body = body + day + "/" + month + "/" + year + "</td><td>";
	
	  body = body + hour + ":" + min + "</td><td>";
	
	  body += output.list[i].weather[0].main;

	  body += "</td><td>";

	  body += Math.floor(output.list[i].main.temp - 273.15);
	  
	  body += "</td> </tr>";
	}
	
	result.innerHTML = body;
  } catch(e) {
    result.innerHTML = "Cannot download from URL";
  }
}
