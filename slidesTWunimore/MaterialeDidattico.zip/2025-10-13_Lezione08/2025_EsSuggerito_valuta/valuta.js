var EUR2GBP = 0.92;
var EUR2CHF = 1.08;
var GBP2CHF = 1.18;
var GBP2EUR = Math.floor(100/EUR2GBP)/100;
var CHF2EUR = Math.floor(100/EUR2CHF)/100;
var CHF2GBP = Math.floor(100/GBP2CHF)/100;

function verificaScelta(id) {

}

function calcolaCambio() {

}

function verificaNumero() {

}






