var col_ok = "#FFFFEE";
var col_err = "#FFEEEE";


function cambiaBordo(s, c) {
	if (c == col_err) 
		document.getElementById(s).style.borderColor = "red";
	else
		document.getElementById(s).style.borderColor = "#409040";
}


function nonvuoto(id) {
	var testo = document.getElementById(id).value;
	
	if (testo == "") {
		cambiaBordo(id,col_err);
		return false;
	}
	
	cambiaBordo(id,col_ok);
	return true;

}


function caricaProvincia() {
	var testo = document.getElementById("regione").value;
	
	if (testo == "") {
		document.getElementById("provincia").innerHTML = "<option value=''>---</option>";
		document.getElementById("provincia").setAttribute("disabled","disabled");
		
	} else {
		document.getElementById("provincia").removeAttribute("disabled");
		if (testo == "ER") {
			document.getElementById("provincia").innerHTML = "<option>Piacenza</option><option>Parma</option><option>Reggio Emilia</option><option>Modena</option><option>Bologna</option><option>Ferrara</option><option>Ravenna</option><option>Forl&igrave; Cesena</option><option>Rimini</option>";
		} else if (testo == "Li") {
			document.getElementById("provincia").innerHTML = "<option>La Spezia</option><option>Genova</option><option>Savona</option><option>Imperia</option>";
		} else if (testo == "Um") {
				document.getElementById("provincia").innerHTML = "<option>Perugia</option><option>Terni</option>";
		}
	}
	
	return nonvuoto("regione");
}


function verificaEta() {

}


function verificaData() {

}

function verificaDati() {

}
