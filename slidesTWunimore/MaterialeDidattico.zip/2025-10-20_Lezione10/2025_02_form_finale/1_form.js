/*
NOTE: 
Aggiornato materiale didattico relativo a 
Lezione_08_2025-10-13 (lunedì scorso):
 - onchange nella select con id regione ora richiama
	la funzione caricaProvincia (non più nonvuoto)
 - aggiornati valori nella tendina della provincia 
	per inserire tutte le province
 - aggiunto return nonvuoto("regione") al termine di caricaProvincia, 
	così risulta non vuota se si seleziona di nuovo l'opzione ---
*/

var col_ok = "#FFFFEE";
var col_err = "#FFEEEE";


function cambiaBordo(s, c) {
	if (c == col_err) 
		document.getElementById(s).style.borderColor = "red";
	else
		document.getElementById(s).style.borderColor = "#409040";
}


function nonvuoto(id) {
	var testo = document.getElementById(id).value;
	
	if (testo == "") {
		cambiaBordo(id,col_err);
		return false;
	}
	
	cambiaBordo(id,col_ok);
	return true;

}


function caricaProvincia() {
	var testo = document.getElementById("regione").value;
	
	if (testo == "") {
		document.getElementById("provincia").innerHTML = "<option value=''>---</option>";
		document.getElementById("provincia").setAttribute("disabled","disabled");
		
	} else {
		document.getElementById("provincia").removeAttribute("disabled");
		if (testo == "ER") {
			document.getElementById("provincia").innerHTML = "<option>Piacenza</option><option>Parma</option><option>Reggio Emilia</option><option>Modena</option><option>Bologna</option><option>Ferrara</option><option>Ravenna</option><option>Forl&igrave; Cesena</option><option>Rimini</option>";
		} else if (testo == "Li") {
			document.getElementById("provincia").innerHTML = "<option>La Spezia</option><option>Genova</option><option>Savona</option><option>Imperia</option>";
		} else if (testo == "Um") {
				document.getElementById("provincia").innerHTML = "<option>Perugia</option><option>Terni</option>";
		}
	}
	
	return nonvuoto("regione");
}


function verificaEta() {
	var e = document.getElementById("eta").value;
	e = parseInt(e);
	
	if (e < 0 || e > 120) {
		alert("Eta' sbagliata!");
		cambiaBordo("eta",col_err);
		return false;
	}
	
	var b = true;
	cambiaBordo("eta",col_ok);
	
	if (document.getElementById("data").value != "")
		b = verificaData();
	
	return b;
}



function verificaData() {
	var dataStringa = document.getElementById("data").value;
	
	var data = new Date(dataStringa);
	
	var oggi = new Date();
	
	//età calcolata sulla base della data di nascita indicata nella form
	var anni = Math.floor(parseInt(oggi-data) / 31536000000); 
	
	//età indicata nella form
	var e = document.getElementById("eta").value; 
	
	if (anni != e) {
		cambiaBordo("eta",col_err);
		cambiaBordo("data",col_err);
		return false;
	}
	
	cambiaBordo("eta",col_ok);
	cambiaBordo("data",col_ok);
	return true;
}



function verificaDati() {
	var b1 = nonvuoto("nome");
	var b2 = nonvuoto("cognome");
	var b3 = nonvuoto("eta");
	var b4 = nonvuoto("regione");
	var b5 = nonvuoto("provincia");
	var b6 = nonvuoto("data");
	var b7 = nonvuoto("password");
	var b8 = nonvuoto("indirizzo1");
	var b9 = nonvuoto("indirizzo2");
	var b10 = nonvuoto("indirizzo3");
	var b11 = nonvuoto("tel");
	if (b1*b2*b3*b4*b5*b6*b7*b8*b9*b10*b11 != 0) {
		alert("Ok!");
	}
}


