"use strict";

const token = "21fd57ae543deb353d9fabff0d3299e3";

let day;
let month;
let year;
let hour;
let min;

/*
function loadCities() {
  let c = "<option id='---' value=''> --- </option>";
  c += "<option id='PC' value='PC'> Piacenza </option>";
  c += "<option id='PR' value='PR'> Parma </option>";
  c += "<option id='RE' value='RE'> Reggio Emilia </option>";
  c += "<option id='MO' value='MO'> Modena </option>";
  c += "<option id='BO' value='BO'> Bologna </option>";
  c += "<option id='FE' value='FE'> Ferrara </option>";
  c += "<option id='RA' value='RA'> Ravenna </option>";
  c += "<option id='FC' value='FC'> Forl&igrave;-Cesena </option>";
  c += "<option id='RN' value='RN'> Rimini </option>";
  
  document.getElementById("city").innerHTML = c;
}
*/

function evaluateDayHour(dayHour) {
  const x = dayHour.split(" ");
  const d = x[0];
  const h = x[1];
	
  const y = d.split("-");
  const z = h.split(":");
  day = y[2];
  month = y[1];
  year = y[0];
	
  hour = z[0];
  min = z[1];
}

function initialize() {  
  
  let s = "";
  const today = new Date();
  let g = today.getDate();
  if (g < 10)
	g = '0' + g;
  let m = today.getMonth()+1;
  let a = today.getFullYear();
	
  s = s + "<option id='---' value=''>---</option>";
  s = s + "<option id='g0'>" + g + "/" + m + "/" + a + "</option>";

  const millis = 1000*60*60*24;
  for (let i=1; i<=4; i++) {
	const newDate = new Date(today.getTime() + i * millis);
		
	g = newDate.getDate();
	if (g < 10)
  	  g = '0' + g;
	m = newDate.getMonth()+1;
	a = newDate.getFullYear();		
	s = s + "<option id=g" + i + ">" + g + "/" + m + "/" + a + "</option>";	
  }		

  document.getElementById("day").innerHTML = s;
  
  document.getElementById("day").className = "error";
  document.getElementById("cityinput").className = "error";
}

async function go() {
  const result = document.getElementById("result");
  
  let city = document.getElementById("cityinput").value;
  city = city.trim();
  city = city.replace(" ", "+");

  if (city.length > 0) {
	document.getElementById("cityinput").className = "ok";  
  }
  
  const dateForecast = document.getElementById("day").value; // data scelta nella tendina
  
  if (dateForecast.length > 0) {
	document.getElementById("day").className = "ok";  
  }
  
  if (city == "" || dateForecast == "")
	return;
  
  const url = "http://api.openweathermap.org/data/2.5/forecast?q="+city+",Italy&appid="+token;
 
  try {
   
	const response = await fetch(url);
	const output = await response.json();

	let body = "";
	
	let i = 0;
	let dayHour = output.list[i].dt_txt;	
	evaluateDayHour(dayHour); // data e ora del primo elemento della lista
	
	let dateList = day + "/" + month + "/" + year; // data del primo elemento della lista
	
	while (dateList != dateForecast) {
	  // se la data nella tendina è diversa da quella attuale, incremento fino a quando trovo per la prima volta la data nella tendina
	  i++; 
	  dayHour = output.list[i].dt_txt;
	  evaluateDayHour(dayHour);
	  dateList = day + "/" + month + "/" + year; 
	}

	while (dateList == dateForecast) {
	  body += "<tr><td>";

      dayHour = output.list[i].dt_txt;
	
	  evaluateDayHour(dayHour);
		
	  body = body + hour + ":" + min + "</td><td>";
	
	  body += output.list[i].weather[0].main;
		
	  body += "</td><td class='tableimg'>";
		
	  //let strImage = findImage(output.list[i].weather[0].main);
	  //body += "<img src = \'" + strImage + ".png\' />";

	  let strImage = output.list[i].weather[0].icon; 
	  body += "<img src = \'https://openweathermap.org/img/wn/" + strImage + "@2x.png\' />";

	  body += "</td><td>";

	  body += Math.floor(output.list[i].main.temp - 273.15);

	  body += "</td> </tr>";
		
	  i++; 
	  dayHour = output.list[i].dt_txt;
	  evaluateDayHour(dayHour);
	  dateList = day + "/" + month + "/" + year; 
	}
	
	result.innerHTML = body; 
  } catch(e) {
    result.innerHTML = "Invalid city or date";
	console.log(e);
  }
}

