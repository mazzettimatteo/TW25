export default function CitySelector() {
  return (
    <p>
    Inserisci una citt&agrave;: 
    <input />
    </p>
  );
}