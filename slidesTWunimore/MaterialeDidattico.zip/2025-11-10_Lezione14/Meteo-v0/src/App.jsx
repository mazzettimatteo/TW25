import './App.css'

import CitySelector from './CitySelector'

export default function App() {
  return (
    <CitySelector />
  )
}
